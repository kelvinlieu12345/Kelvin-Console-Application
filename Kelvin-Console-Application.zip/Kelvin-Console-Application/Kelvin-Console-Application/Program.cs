﻿using System;

namespace Kelvin_Console_Application
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("\n Please enter your name ");
            var name = Console.ReadLine();
            var date = DateTime.Now;
            Console.WriteLine($"\nHello, {name}, on {date:d} at {date:t}!");
            Console.Write("\n...");
            Console.ReadKey(true);
        }
    }
}
